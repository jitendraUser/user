from django.shortcuts import render
from django.http import HttpResponse
from . models import Counter
from django.contrib.auth.models import User,auth
from django.contrib.auth import authenticate,logout,login
from django.contrib import messages
from . models import addpizza,CustomerModel,OrderModel
# Create your views here.
def index(request):
    return render(request,'customer_home.html')

def clogin(request):
    return render(request,'customer_login.html')


def cloginview(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username = username, password = password)
        if user is not None:
            auth.login(request,user)
            userdata1=User.objects.filter(username=username)  
            pizzaList=addpizza.objects.all()    
            return render(request,"customer_profile.html",{'userdata':userdata1,'allpizza':pizzaList})
        else:
            messages.info(request, "Invalid Credentials")
            return render(request,'customer_login.html') 
    else:
        
        return render(request,'customer_login.html') 

def placeorder(request):
    user = request.user
    #phoneno = CustomerModel.objects.filter(userid = request.user.id)[0].phoneno
    
    address = request.POST['address']
    orderiteams  = " "
    for pizza in addpizza.objects.all():
        pizzaid = pizza.id
        name = pizza.pizza_name
        price = pizza.price
        quantity = request.POST.get(str(pizzaid)," ")
        if str(quantity)!="0" and str(quantity)==" ":
            orderiteams  = orderiteams +" Pizza Name:"+ name + " "+"Price : " + str(price) + " " + "quantity : "+quantity+" "

    print(name)    
    OrderModel(username=user,address=address,orderiteams=orderiteams).save()
    messages.add_message(request,messages.SUCCESS,"Your Order Placed")
    pizzaList=addpizza.objects.all()
    return render(request,"customer_profile.html",{'allpizza':pizzaList}) 
def c_logout(request):
    logout(request)
    return render(request,'customer_login.html') 


def index1(request):
    return render(request,'index.html')

def increment(request):
    obj = Counter.objects.filter(id=1)[0]
    obj.number = obj.number+1
    obj.save()
    num = Counter.objects.filter(id=1)
    return render(request,'index.html',{'list':num})    

def decrement(request):
    obj = Counter.objects.filter(id=1)[0]
    obj.numer = obj.number-1
    obj =  Counter.objects.filter(id=1).update(number=obj.numer)
    num = Counter.objects.filter(id=1)
    return render(request,'index.html',{'list':num})    


def reset(request):
    obj = Counter.objects.filter(id=1)
    obj.numer = 0
    obj =  Counter.objects.filter(id=1).update(number=obj.numer)
    num = Counter.objects.filter(id=1)
    return render(request,'index.html',{'list':num})            

def adminloginview(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username = username, password = password)
        if user is not None:
            #messages.add_message(request,messages.ERROR,"Invalid Credentials")
            
            return render(request,'admin_profile.html')  
        else:
            messages.info(request, "Invalid Credentials")
            return render(request,'admin_login.html')  
    else:
        
        return render(request,'admin_login.html')   

def regsupadmin(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']
        user = User.objects.create_superuser(username = username, password = password,email=email)

        return HttpResponse("User Created Successfully ")
    else:
        return render(request,'admin_reg.html')  


def admin_logout(request):
    logout(request)
    return render(request,'admin_login.html') 


def newpizza(request):
    if request.method == "POST":
        pizza_name = request.POST['pname']
        price = request.POST['price']
        pizza = addpizza(pizza_name=pizza_name,price=price)
        pizza.save()
        list= addpizza.objects.all()
        return render(request,'admin_profile.html',{'pizzalist':list})
def editpizza(request,id):
    list= addpizza.objects.filter(id=id)
    return render(request,'editpizza.html',{'pizzalist':list})


def deletepizza(request,id):
    addpizza.objects.filter(id=id).delete()
    list= addpizza.objects.all()
    return render(request,'admin_profile.html',{'pizzalist':list})

def login(request):
    return render(request,'admin_login.html')

def updatepizza(request):
    pizza_name = request.POST['pname']
    price = request.POST['price']
    id = request.POST['id']
    addpizza.objects.filter(id=id).update   (pizza_name=pizza_name,price=price)
    list= addpizza.objects.all()
    return render(request,'admin_profile.html',{'pizzalist':list})




def customer_reg(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']
        phoneno =request.POST['phoneno']
        if User.objects.filter(username = username).exists():
            messages.add_message(request,messages.SUCCESS,"User already exists")
            return render(request,'customer_home.html')  
        User.objects.create_user(username = username, password = password,email=email)
        lastobject = len(User.objects.all())-1
        CustomerModel(userid = User.objects.all()[int(lastobject)].id,phoneno=phoneno).save()
        messages.add_message(request,messages.SUCCESS,"User Created")
        return HttpResponse("User Created Successfully ")
        #return redirect('homepage')
    else:
        return render(request,'customer_home.html')  
