

from django.urls import path
from .  import views
urlpatterns = [
    path('', views.index),
    path('clogin',views.clogin),
    path('cloginview',views.cloginview),
    path('placeorder',views.placeorder),
    path('c_logout',views.c_logout),
    path('increment',views.increment),
    path('decrement',views.decrement),
    path('reset',views.reset),
    path('supadmin',views.login),
    path('supprofile',views.adminloginview),
    path('regsupadmin',views.regsupadmin),
    path('admin_logout',views.admin_logout),
    path('addpizza',views.newpizza),
    path('editpizza/<int:id>/',views.editpizza),
    path('deletepizza/<int:id>/',views.deletepizza),
    path('updatepizza',views.updatepizza),
    path('customer_reg',views.customer_reg),

]
