from django.apps import AppConfig


class PizzaAppConfig(AppConfig):
    name = 'pizza_app'
