from django.db import models

# Create your models here.
class Counter(models.Model):
    number = models.IntegerField()

class addpizza(models.Model):
    pizza_name=models.CharField(max_length=30)
    price= models.IntegerField()
    class Meta:
        db_table = "pizza"

class CustomerModel(models.Model):
    userid = models.CharField(max_length=10)
    phoneno = models.CharField(max_length=10)
    class Meta:
        db_table = "customermodel"

class OrderModel(models.Model):
    username = models.CharField(max_length=30)
    phoneno = models.CharField(max_length=30)
    address = models.CharField(max_length=30)
    orderiteams  = models.CharField(max_length=30)
    class Meta:
        db_table = "orderTable"